<?php

if(!defined('IN_DISCUZ')) {
       exit('Access Denied');
}

class plugin_ldap_pass {

}

class plugin_ldap_pass_member extends plugin_ldap_pass {
    function logging_top(){
        global $_G;
        if ($_G['cache']['plugin']['ldap_pass']['pass_open']==1)
        {
            if($_GET['action'] == 'login' && $_GET['loginsubmit'] == 'yes')
            {
                if($_G['setting']["pwdsafety"]=="0"){
                    list($seccodecheck) = seccheck('login');
                    $seccodestatus = !empty($_GET['lssubmit']) ? false : $seccodecheck;
                    if(!submitcheck('loginsubmit', 1, $seccodestatus)) {
                        exit();
                    }else{
                        if(!empty($_GET['auth'])) {
                            list($username, $password, $questionexist) = explode("\t", authcode($_GET['auth'], 'DECODE', $_G['config']['security']['authkey']));
                            $username = dhtmlspecialchars($username);
                        }else{
                            $username = $_GET["loginfield"]?$_GET[$_GET["loginfield"]]:$_GET[$_GET["fastloginfield"]];
                            $username = dhtmlspecialchars(preg_replace('/\s+/', '', $username));
                            $password = addslashes($_GET['password']);
                            if($username==""){
                                showmessage('username_nonexistence');
                            }
                            if(!$_GET['password'] || $_GET['password'] != addslashes($_GET['password'])) {
                                showmessage('profile_passwd_illegal');
                            }
                        }

                        require_once DISCUZ_ROOT . './source/plugin/ldap_pass/class/Ldappass.class.php';
                        $LP = new Ldappass($_G['cache']['plugin']['ldap_pass']);
                        $LP->ADlogin($username,$password);
                    }
                }else{
                    showmessage('ldap_pass:error5000', NULL, array(), array('alert' => 'error'));
                }
            }
        }
        return '';
    }
}
