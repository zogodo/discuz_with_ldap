<?php
/**
 * mail:mail@codeeel.com
 * site:www.codeeel.com
 * by jim.zhong
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

define('LDAP_PASS', TRUE);

$action = $_GET['action'];
if(!in_array($action, array('active')))
    showmessage('ldap_pass:paramError', './', array(), array('alert' => 'error'));

if($action == 'active')
{
    $referer = dreferer();
    if(strpos($referer, 'plugin.php?id=ldap_pass:pass') !== false)
        $referer = './index.php';

    if(strpos($referer, $_SERVER['HTTP_HOST']) === false)
        $referer = './' . $referer;

    require_once DISCUZ_ROOT . './source/plugin/ldap_pass/class/Ldappass.class.php';
    loaducenter();
    if($_G['uid'])
    {
            $ucsynlogin = uc_user_synlogin($_G['uid']);
            $param = array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle'], 'uid' => $_G['uid']);
            showmessage('login_succeed', $referer, $param, array('showdialog' => 1, 'locationtime' => true, 'extrajs' => $ucsynlogin, 'alert' => 'right'));
    }

    session_start();

    if(is_array($_SESSION['active']) && $_SESSION['active']["samaccountname"]){
        extract($_SESSION['active']);
        if($user = alreadyRegister($samaccountname)){
            showmessage(lang('plugin/ldap_pass', 'alreadybinding').$samaccountname, $referer, null, array('alert' => 'error'));
        }

        if(!submitcheck('activesubmit')){
            include template('ldap_pass:active');
        }else{
            $username = $_GET["username"]?:$samaccountname;
            $username = daddslashes(trim($username));
            require_once DISCUZ_ROOT . './source/plugin/ldap_pass/class/UsernameValidate.class.php';
            $userValidate = new UsernameValidate();

            $usernameMsg = $userValidate->validate($username);
            if($usernameMsg)
                showmessage($usernameMsg, NULL, array(), array('alert' => 'error'));
            $uniqueMsg = $userValidate->checkUsernameUniqueness($username, $_G['uid']);
            if($uniqueMsg)
                showmessage($uniqueMsg, NULL, array(), array('alert' => 'error'));
            $username = $userValidate->cleanUsername($username);

            $fromuid = !empty($_G['cookie']['promotion']) && $_G['setting']['creditspolicy']['promotion_register'] ? intval($_G['cookie']['promotion']) : 0;
            $email = $mail;
            $regip = $_G['clientip'];
            $newusergroupid = $_G['setting']['newusergroupid'];
            $uid = NULL;
            $resultList = ldappass_uc_user_register($username, $password, $regip, $email);
            if(in_array($resultList,array(-1,-2,-3))){
                showmessage('ldap_pass:activeerror', NULL, array(), array('alert' => 'error'));
            }if($resultList==-6){
                showmessage('ldap_pass:mailrepeat', NULL, array(), array('alert' => 'error'));
            }elseif($resultList){
                list($uid, , $email) = $resultList;
            }else{
                showmessage('register_activation_invalid', NULL, array(), array('alert' => 'error'));
            }
            $password=md5($password);
            $initData = array('credits' => explode(',', $_G['setting']['initcredits']), 'profile'=>array(), 'emailstatus' => 0);
            $newuser = compact('uid', 'username', 'password', 'email', 'regip', 'newusergroupid');
            ldappass_dz_user_register($newuser, $initData);
            require_once libfile('function/member');
            require_once libfile('cache/userstats', 'function');
            build_cache_userstats();

            setloginstatus(array(
                'uid' => $uid,
                'username' => $username,
                'password' => $password,
                'groupid' => $newusergroupid,
            ), 0);
            include_once libfile('function/stat');
            updatestat('register');

            C::t('#ldap_pass#common_member_ldappass')->update($samaccountname, array('uid' => $uid));
            $param = array('username' => $username, 'usergroup' => $_G['group']['grouptitle'], 'uid' => $_G['uid']);
            showmessage('login_succeed', $referer, $param, array('alert' => 'right'));
        }
    }else{
        showmessage("logout_succeed", $referer, array("ucsynlogout"=>""), array('alert' => 'right'));
    }
}

function  alreadyLdappass($username,$uid=false){
    if($uid){
        $User = C::t('#ldap_pass#common_member_ldappass')->fetch_by_uid($username);
    }else{
        $User = C::t('#ldap_pass#common_member_ldappass')->fetch_by_account($username);
    }
    return $User?:false;
}

function  alreadyRegister($username,$uid=false){
    if($User=alreadyLdappass($username,$uid)){
        if($uid){
            if ($User['uid']==$username) {
                $dzUser = C::t('common_member')->fetch($User['uid']);
            }
        }else{
            $dzUser = C::t('common_member')->fetch($User['uid']);
        }
        return $dzUser;
    }else{
        return false;
    }
}

function ldappass_uc_user_register($username, $password,$regip, $email=null){
    $email = $email ? $email : "{$username}@".isDomain($_SERVER['SERVER_NAME']);
    loaducenter();
    $uid = uc_user_register($username, $password, $email, 0, '', $regip);
    ;
    if ($uid == -3 && ($ucUser = uc_get_user(addslashes($username))))   //uc用户存在
    {
        $uid = intval($ucUser[0]);
        if($ucUser[2])
            $email = $ucUser[2];
    }

    if($uid > 0)
        return array($uid, $password, $email);
    else
        return $uid;
}


function ldappass_dz_user_register($user, $initData) {
    C::t('common_member')->insert($user['uid'], $user['username'], $user['password'], $user['email'], $user['regip'], $user['newusergroupid'], $initData);
}


function isDomain($str = '')
{
    return !empty($str) && !preg_match('/^-|-$|--|-\.|\.-/', $str) && preg_match('/^([\w-]+\.)?[\w-]+' . self::RegExpSuffix() . '$/', $str) ? true : false;
}

function RegExpSuffix()
{
    return '(' . str_replace('.', '\.', implode('|', self::allowDomainSuffix())) . ')';
}

function allowDomainSuffix()
{
    $arr = array('.com', '.com.cn', '.cn', '.net', '.net.cn', '.org', '.org.cn', '.gov.cn', '.hk', '.cc', '.info', '.biz', '.mobi', '.us', '.me', '.co', '.co.jp', '.edu', '.tv', '.la');
    sort($arr);
    return array_unique(array_reverse($arr));
}
