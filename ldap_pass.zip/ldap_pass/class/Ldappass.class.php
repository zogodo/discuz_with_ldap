<?php

if(!defined('IN_DISCUZ')) 
	exit('Access Denied');

class Ldappass {

    private $hosts;
    private $ports;
    private $ldaps;
    private $account;
    private $password;
    private $dn;
    private $filter;
    private $timeout;

    private $connect;

    /**
     * Ldappass constructor.
     */
    public function __construct($setting)
    {
        $this->hosts = $setting["hosts"];
        $this->ports = $setting["ports"];
        $this->ldaps = $setting["ldaps"];
        $this->account = $setting["account"];
        $this->password = $setting["password"];
        $this->dn = $setting["dn"];
        $this->filter = $setting["filter"]==""?"":"(".$setting["filter"].")";
        $this->timeout = $setting["timeout"];
        $this->samaccountname = $setting["samaccountname"];
        $this->sn = $setting["sn"];
        $this->givenname = $setting["givenname"];
        $this->mail = $setting["mail"];
        $this->mailnickname = $setting["mailnickname"];
        $this->mobile = $setting["mobile"];

        ldap_set_option($this->connect, LDAP_OPT_NETWORK_TIMEOUT, $this->timeout);
        ldap_set_option($this->connect, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($this->connect, LDAP_OPT_REFERRALS, 0);
        $this->connect = ldap_connect(($this->ldaps==1?"ldaps://":"ldap://").$this->hosts,$this->ports?:389);
    }

    public function ADlogin($username, $password) {
        if(ldap_bind($this->connect, $this->account, $this->password)){
            if (strpos($username,"@")) {
                $filter="(userprincipalname=".$username.")".$this->filter;
            }else{
                $filter="(samaccountname=".$username.")".$this->filter;
            }
            $result= ldap_search($this->connect, $this->dn,$filter);
            $entry= ldap_get_entries($this->connect,$result);//获得查询结果

            if($entry["count"]==1){
                $samaccountname = strtolower(@$entry[0][$this->samaccountname][0]);
                $userprincipalname = @$entry[0]["userprincipalname"][0];
                $mail = @$entry[0][$this->mail][0];
                $mailnickname = @$entry[0][$this->mailnickname][0];
                $mobile = @$entry[0][$this->mobile][0];
                $sn = @$entry[0][$this->sn][0];
                $givenname = @$entry[0][$this->givenname][0];

                if($samaccountname==strtolower($username)){
                    if(ldap_bind($this->connect, $userprincipalname, $password)){

                        ldap_close($this->connect);
                        if($dzUser = $this->alreadyRegister($samaccountname)){
                            loaducenter();
                            require_once libfile('function/member');
                            setloginstatus($dzUser, 0);
                        }else{
                            if(!is_array($this->alreadyLdappass($samaccountname))) {
                                C::t('#ldap_pass#common_member_ldappass')->insert(
                                    array(
                                        'ldappass_account' => $samaccountname,
                                        'uid' => 0,
                                        'createtime' => time(),
                                        'userprincipalname' => $userprincipalname,
                                        'sn' => $sn,
                                        'givenname' => $givenname,
                                        'mail' => $mail,
                                        'mailnickname' => $mailnickname,
                                        'mobile' => $mobile,
                                    )
                                );
                            }

                            ldap_close($this->connect);

                            session_start();
                            $_SESSION['active']=compact(
                                'samaccountname',
                                'userprincipalname',
                                'mail',
                                'mailnickname',
                                'mobile',
                                'sn',
                                'givenname',
                                'password'
                            );

                            if($_GET['inajax']){
                                ob_end_clean();
                                ob_start();
                                @header("Expires: -1");
                                @header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
                                @header("Pragma: no-cache");
                                @header("Content-type: text/xml; charset=".CHARSET);
                                echo '<?xml version="1.0" encoding="'.CHARSET.'"?>'."\r\n";
                                echo '<root><![CDATA[';
                                echo '<div style="padding: 5px;font-size: 13px;">';
                                echo '<script type="text/javascript">top.location.href="./plugin.php?id=ldap_pass:pass&action=active";</script>';
                                echo '<strong>'.lang('plugin/ldap_pass', 'goactive').'</strong>';
                                echo '</div>]]></root>';
                                exit;
                            }
                            dheader('location: ./plugin.php?id=ldap_pass:pass&action=active');
                            exit;
                        }
                    }
                }
            }
        }else{
            ldap_close($this->connect);
            showmessage('ldap_pass:error5001', NULL, array(), array('alert' => 'error'));
        }
    }





    public  function  alreadyLdappass($username){
        $User = C::t('#ldap_pass#common_member_ldappass')->fetch_by_account($username);
        return $User?:false;
    }

    public  function  alreadyRegister($username){
        if($User=$this->alreadyLdappass($username)){
            $dzUser = C::t('common_member')->fetch($User['uid']);
            return $dzUser;
        }else{
            return false;
        }
    }


}