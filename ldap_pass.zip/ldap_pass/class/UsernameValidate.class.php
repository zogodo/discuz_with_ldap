<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class UsernameValidate {
    const USERNAME_MIN_LENGTH = 3;
    const USERNAME_MAX_LENGTH = 15;

    public function validate($username){
        $discuzCheck = new discuz_censor();
        $oriUsername = $username;

        if (empty($username))
            return lang('plugin/ldap_pass', 'validate1');
        elseif(preg_match("/(".lang('plugin/ldap_pass', 'validate11').")/i",$username))
            return lang('plugin/ldap_pass', 'validate2');
        elseif(preg_match("/^".lang('plugin/ldap_pass', 'validate12')."/",$username))
            return lang('plugin/ldap_pass', 'validate3');
        elseif(!preg_match("/^[\x{4e00}-\x{9fa5}a-zA-Z0-9_]+$/u",$username))
            return lang('plugin/ldap_pass', 'validate4');
        elseif(preg_match("/^13[0-9]{1}[0-9]{8}$|15[0189]{1}[0-9]{8}$|189[0-9]{8}$/",$username))
            return lang('plugin/ldap_pass', 'validate5');
        elseif(strlen($username) > self::USERNAME_MAX_LENGTH)
            return lang('plugin/ldap_pass', 'validate6');
        elseif(strlen($username) < self::USERNAME_MIN_LENGTH)
            return lang('plugin/ldap_pass', 'validate7'). self::USERNAME_MIN_LENGTH . lang('plugin/ldap_pass', 'validate8');
        elseif(($checkCode = $discuzCheck->check($username)) !== 0){
            if($checkCode == 3 && $oriUsername == $username)
                return FALSE;

            return lang('plugin/ldap_pass', 'validate9');
        }

        return FALSE;
    }

    public function checkUsernameUniqueness($username, $uid = 0){
        if($uid)
        {
            $sql = 'SELECT uid FROM %t WHERE username=%s and uid <> %d';
            $params = array('common_member', $username, $uid);
        }
        else
        {
            $sql = 'SELECT uid FROM %t WHERE username=%s';
            $params = array('common_member', $username);
        }

        if (DB::fetch_first($sql, $params))
            return lang('plugin/ldap_pass', 'validate10');
        else
            return FALSE;
    }

    public function cleanUsername($username){
        return dhtmlspecialchars(preg_replace("/\s+/", "", $username));
    }
}