﻿<?php
if(!defined('IN_DISCUZ')|| !defined('IN_ADMINCP')){
    exit('Access Denied');
}

$table = DB::table('common_member_ldappass');
$tableLog = DB::table('common_member_ldappass_log');
$tableChgLog = DB::table('common_member_ldappass_chg_log');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS  `pre_common_member_ldappass` (
  `ldappass_account` varchar(26) NOT NULL COMMENT '帐号',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '论坛UID',
  `createtime` int(11) DEFAULT '0',
  `userprincipalname` varchar(64) DEFAULT NULL,
  `sn` varchar(32) DEFAULT NULL,
  `givenname` varchar(32) DEFAULT NULL,
  `mail` varchar(128) DEFAULT NULL,
  `mailnickname` varchar(32) DEFAULT NULL,
  `mobile` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ldappass_account`),
  KEY `uid` (`uid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='帐号绑定表';

EOF;
runquery($sql);
$finish = TRUE;
?>