<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_common_member_ldappass extends discuz_table {

	public function __construct() {

		$this->_table = 'common_member_ldappass';
		$this->_pk    = 'ldappass_account';
		parent::__construct();
	}

	public function fetch_by_account($account){
		return DB::fetch_first("SELECT * FROM %t WHERE ldappass_account=%s", array($this->_table, $account));
	}


	public function fetch_by_uid($uid){
		return DB::fetch_first("SELECT * FROM %t WHERE uid>0 and uid=%s", array($this->_table, $uid));
	}


}